# awsLambdaRequest

- Simple api Request using python request module 
- with set of number
